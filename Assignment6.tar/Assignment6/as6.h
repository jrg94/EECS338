/**
 * Author: Jeremy Griffith
 * Assignment 6 Header
 */

#include "cookies.h"
#include <stdlib.h>
#include <stdio.h>

#define MAX_COOKIES 20

#define TINA 1
#define JUDY 2

int askForCookies(CLIENT *c);
